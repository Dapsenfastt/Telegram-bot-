import logging
import os
import re
import tempfile
import uuid

import yt_dlp
from telegram import Update
from telegram.constants import ChatAction
from telegram.ext import Application, MessageHandler, CommandHandler, ContextTypes, filters

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

BOT_TOKEN = os.environ.get("BOT_TOKEN")

# Telegram bots can only send files up to 50 MB via the standard Bot API.
MAX_FILE_SIZE_MB = 50

URL_PATTERN = re.compile(
    r"https?://(www\.)?"
    r"(youtube\.com|youtu\.be|"
    r"tiktok\.com|vt\.tiktok\.com|"
    r"instagram\.com|"
    r"twitter\.com|x\.com)"
    r"/\S+",
    re.IGNORECASE,
)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(
        "Send me a share link from YouTube, TikTok, Instagram, or Twitter/X "
        "and I'll download the video for you.\n\n"
        f"Note: Telegram bots can only send files up to {MAX_FILE_SIZE_MB} MB."
    )


def find_url(text: str) -> str | None:
    match = URL_PATTERN.search(text)
    return match.group(0) if match else None


def download_video(url: str, out_dir: str) -> str:
    """Downloads the video with yt-dlp and returns the local file path."""
    output_template = os.path.join(out_dir, f"{uuid.uuid4()}.%(ext)s")
    ydl_opts = {
        "outtmpl": output_template,
        "format": "mp4/best[ext=mp4]/best",
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
        # Keep the final file under Telegram's limit where possible.
        "format_sort": ["res:720"],
    }
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(url, download=True)
        filepath = ydl.prepare_filename(info)
    return filepath


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    text = update.message.text or ""
    url = find_url(text)

    if not url:
        await update.message.reply_text(
            "I couldn't find a supported link in your message. "
            "Send a YouTube, TikTok, Instagram, or Twitter/X share link."
        )
        return

    status_msg = await update.message.reply_text("Downloading your video, hang tight...")
    await context.bot.send_chat_action(chat_id=update.effective_chat.id, action=ChatAction.UPLOAD_VIDEO)

    with tempfile.TemporaryDirectory() as tmp_dir:
        try:
            filepath = download_video(url, tmp_dir)
        except Exception as e:
            logger.error("Download failed for %s: %s", url, e)
            await status_msg.edit_text(
                "Sorry, I couldn't download that video. The link might be private, "
                "region-locked, or unsupported."
            )
            return

        try:
            size_mb = os.path.getsize(filepath) / (1024 * 1024)
        except OSError:
            await status_msg.edit_text("Something went wrong reading the downloaded file.")
            return

        if size_mb > MAX_FILE_SIZE_MB:
            await status_msg.edit_text(
                f"The video is {size_mb:.1f} MB, which is over Telegram's "
                f"{MAX_FILE_SIZE_MB} MB bot upload limit, so I can't send it here."
            )
            return

        await status_msg.edit_text("Uploading...")
        try:
            with open(filepath, "rb") as video_file:
                await update.message.reply_video(video=video_file, supports_streaming=True)
            await status_msg.delete()
        except Exception as e:
            logger.error("Upload failed: %s", e)
            await status_msg.edit_text("Downloaded fine, but I couldn't send the file back to you.")


def main() -> None:
    if not BOT_TOKEN:
        raise RuntimeError("BOT_TOKEN environment variable is not set.")

    application = Application.builder().token(BOT_TOKEN).build()

    application.add_handler(CommandHandler("start", start))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    logger.info("Bot starting...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
