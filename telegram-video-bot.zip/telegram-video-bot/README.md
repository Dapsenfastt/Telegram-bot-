# Telegram Video Download Bot

Downloads videos from share links (YouTube, TikTok, Instagram, Twitter/X) sent to it in a chat, using `yt-dlp`.

## 1. Create your bot
1. In Telegram, message **@BotFather**.
2. Send `/newbot` and follow the prompts.
3. Copy the token it gives you (looks like `123456789:ABC-defGhIjklMnoPQRstuVWxyz`).

## 2. Run locally (optional, to test)
```bash
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
export BOT_TOKEN=your-token-here   # Windows: set BOT_TOKEN=your-token-here
python bot.py
```
You'll also need `ffmpeg` installed locally (`brew install ffmpeg` / `apt install ffmpeg` / download for Windows).

## 3. Push to GitHub
```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```

## 4. Deploy on Railway
1. Go to railway.app → **New Project** → **Deploy from GitHub repo** → pick this repo.
2. Once created, open the service → **Variables** tab → add:
   - `BOT_TOKEN` = your token from BotFather
3. Railway will auto-detect Python and use Nixpacks. The included `nixpacks.toml` makes sure `ffmpeg` gets installed (yt-dlp needs it to merge video/audio streams).
4. Under **Settings → Deploy**, confirm the start command is `python bot.py` (the `Procfile` sets this automatically as a `worker` process — Railway should pick it up).
5. Deploy. Check the **Logs** tab for `Bot starting...` to confirm it's running.

## Notes and limits
- Telegram bots can only send files up to **50 MB** through the normal Bot API. Larger videos will be rejected with a message to the user.
- Downloading content some users don't have the rights to may violate the source platform's Terms of Service — this bot is best used for personal, fair-use downloads (e.g. saving your own posts or links you have permission to save).
- Private, age-restricted, or region-locked content may fail to download.
- If a platform changes its site and yt-dlp breaks, run `pip install -U yt-dlp` to get the latest fix (the yt-dlp maintainers update it very frequently).

## How it works
- The bot listens for any text message containing a supported URL.
- It runs `yt-dlp` to fetch the best available MP4 (capped near 720p to help stay under the size limit).
- It sends the resulting video file back to the chat, then deletes the temp file.
